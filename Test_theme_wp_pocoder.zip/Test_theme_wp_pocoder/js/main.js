
jQuery(document).ready(function () {
  jQuery('.slider').bxSlider({
    mode: 'fade',
    captions: true,
  });
   // ক্লাস নং(৩১) owl carousel কল করা হয়ছে
  jQuery(".owl-carousel").owlCarousel({
    autoplay: true,
    items: 1,
   });
});