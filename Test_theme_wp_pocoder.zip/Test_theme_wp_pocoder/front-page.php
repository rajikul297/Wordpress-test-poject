<?php
//* Theme Front Page
get_header();
?>
<!--c28 slider_area -->
<section id="slider_area">
  <div class="slider">
      <?php query_posts('post_type=slider&post_status=publish&posts_per_page=3&order=ASC&paged'. get_query_var('post'));
      
      // যদি পোস্ট থাকে তাহলে পোস্ট দেখাবে
      if(have_posts()) :
        while(have_posts()) : the_post();
      ?>

      <div>
          <?php the_post_thumbnail('slider');?>
        </div>

      <?php endwhile;endif;?>
    </div>
</section>
<!-- owl-carousel -->
<section id="slider_area">
  <div id="owl_slider" class="owl-carousel owl-theme">
      <?php query_posts('post_type=slider&post_status=publish&posts_per_page=3&order=ASC&paged'. get_query_var('post'));
      
      // যদি পোস্ট থাকে তাহলে পোস্ট দেখাবে
      if(have_posts()) :
        while(have_posts()) : the_post();
      ?>

      <div>
          <?php the_post_thumbnail('slider');?>
        </div>

      <?php endwhile;endif;?>
    </div>
</section>

<div id="homepage_post">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <?php dynamic_sidebar('homepage-1'); ?>
      </div>
    </div>
  </div>
</div>

<!-- service_area -->
<section id="service_area">
  <div class="container">
    <div class="row">
      <?php query_posts('post_type=service&post_status=publish&posts_per_page=3&order=ASC&paged'. get_query_var('post'));
      
      // যদি পোস্ট থাকে তাহলে পোস্ট দেখাবে
      if(have_posts()) :
        while(have_posts()) : the_post();
      ?>

      <div class="col-md-4">
        <div class="child_service">
          <h1><?php the_title();?></h1>
          <?php the_post_thumbnail('service');?>
          <?php the_excerpt(  );?>
        </div>
      </div>

      <?php endwhile;endif;?>
    </div>
  </div>
</section>




<?php get_footer(); ?>