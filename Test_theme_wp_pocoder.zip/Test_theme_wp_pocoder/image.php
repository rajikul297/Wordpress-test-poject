<?php
// (index.php )এটার মেন হেডার ফাইল (header.php) তে দেওয়া আছে ওখান থেকে (header) কাজ করে এই ফাংশন এর মাধ্যমে
get_header();
?>

  
  <!-- ক্লাস নাম্বার {08} 
  সেটআপ হোমপেজ (এই ক্লাসের সকল কাজ ওয়ার্ডপ্রেসের হোম সেকশনে করা হয়েছে)-->
  <section id="body_area">
    <div class="container">
      <div class="row">
       <div class="col-md-12">
        <?php get_template_part('template_part/post_setup');?>
        <img src="<?php echo $post->guid;?>" alt="<?php echo get_the_title();?>">
        <img src="<?php echo esc_url( $post->guid );?>" alt="<?php echo esc_attr(the_title());?>">
        <?php var_export($post); ?>
        <p><a href="<?php echo $post->guid;?>">Donload</a></p>
       </div>
      </div>
    </div>
  </section>

<?php
// (footer.php )এটার মেন ফাইল (footer.php) তে দেওয়া আছে ওখান থেকে (footer) কাজ করে এই ফাংশন এর মাধ্যমে
get_footer();
?>