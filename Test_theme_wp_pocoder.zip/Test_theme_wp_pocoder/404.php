<?php
/*
*৪০৪. ফাইল
*The template for displaing
*/
get_header();?>

  <section id="body_area">
    <div class="container">
      <div class="row">
       <div class="col-md-12 error_page">
        <p>404 page note found</p>
        <h1>Oops! Lock Like Something was wrong</h1>
       <div class="error_search_form">
        <?php get_search_form();?>
       </div>
       <a href="<?php echo home_url()?>" class="homepage">Go Home Page</a>
       </div>
      </div>
    </div>
  </section>

<?php
// (footer.php )এটার মেন ফাইল (footer.php) তে দেওয়া আছে ওখান থেকে (footer) কাজ করে এই ফাংশন এর মাধ্যমে
get_footer();
?>