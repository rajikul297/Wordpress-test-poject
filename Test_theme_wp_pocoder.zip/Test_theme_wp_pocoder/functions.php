<?php
// <!-- =============Theme Function==================== -->

// <!-- title fuction -->
include_once('inc/default.php');

// সিএসএস জাভাস্ক্রিপ্ট ফাইল কে কল করা হয়েছে
include_once('inc/enqueue.php');

// থিম ফাংশন ফাইল কে কল করা হয়েছে (এই ফাইলে থাকবে)
include_once('inc/theme_function.php');

//  মেনু রেজিস্টার
include_once('inc/menu_register.php');

//  widgest রেজিস্টার
include_once('inc/widgest_register.php');

//  cusrom_post রেজিস্টার
include_once('inc/custom_post.php');

//  shortcode রেজিস্টার
include_once('inc/shortcode.php');

