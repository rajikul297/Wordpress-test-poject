<?php

// Sidebar Area
?>
<!-- এখানে সাইডবারের আইডি দিলে নির্দিষ্ট সাইডবার শো করবে -->
<?php dynamic_sidebar('sidebar-1');?>