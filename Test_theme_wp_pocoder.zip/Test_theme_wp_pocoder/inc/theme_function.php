<?php


// ক্লাস নাম্বার {04}
function rajikul_customize_register($wp_customize){
  $wp_customize->add_section('rajikul_header_area',array(
    'title'=>__('header area','rajikul_language'),
    'description'=>'if you interest updet header area ',
  ));
  $wp_customize-> add_setting('rajiku_logo',array(
    'default'=>get_bloginfo('template_directory'). '/img/logo.png',
  ));
  // এটা দিয়ে কন্ট্রোল করে
  $wp_customize->add_control(new WP_Customize_Image_Control(
    $wp_customize,'rajiku_logo',array(
      'label'=>'logo upload',
      'description'=>'if you interest updet header area ',
           // এগুলা সেটিং এবং সেকশন এর এক্সেস নেওয়ার কাজ করে
      'setting'=>'rajiku_logo',
      'section'=>'rajikul_header_area',
    )
    ));


    /* ==========================================
      ক্লাস নাম্বার {07}
    Menu মেনু পজিশন অপশন
   এটা দিয়ে নেভ মেনু কে ডানে বামে করে
 ============================================================ */
 $wp_customize->add_section('rajikul_menu_option',array(
  'title'=>__('menu position option','rajikul_language'),
  'description'=>'if you intarest chenge yuor menu position',
 ));

  $wp_customize->add_setting('rajikul_menu_position',array(
    'default'=>'right_menu',
  ));

   $wp_customize->add_control('rajikul_menu_position',array(
    'label'=>'menu position',
    'description' =>'select your menu position',
       // এগুলা সেটিং এবং সেকশন এর এক্সেস নেওয়ার কাজ করে
    'setting'=>'rajikul_menu_position',
    'section'=>'rajikul_menu_option',
     // left/right লেফট রাইট সিলেক্ট করার অপশন
     'type'=>'radio', 'choices'=> array(
      'left_menu'=>'left menu',
      'right_menu'=>'right menu',
      'center_menu'=>'center menu',
     )
   ));


    /* ==========================================
      ক্লাস নাম্বার {10}
    এটা দিয়ে কপিরাইট এরিয়ার টেক্সট চেঞ্জ করার অপশন 
 ============================================================ */
 $wp_customize-> add_section('rajikul_footer_option', array(
  'title'=>__('footer option','rajikul_language'),
  'description'=>'if you interest your copyright option',
 ));

 $wp_customize->add_setting('rajikul_copyright_section',array(
  'default'=>'Copyright 2022 | rajikul mm',
 ));

 $wp_customize->add_control('rajikul_copyright_section',array(
  'label'=>'copyright Ooption',
  'description'=>'if Need interest change your copyright option',
  'section'=>'rajikul_footer_option',
  'setting'=>'rajikul_copyright_section',
 ));

/*===========================
      ক্লাস নং {২৩}
 কালার চেন্জ করার ফাংশন
 ===========================*/
 $wp_customize->add_section('rejikul_colors' ,array(  
  'title'=>__('Theme Color','rajikul_language'),
  'description'=>'if you need chenge your color',
 ));
 $wp_customize->add_setting('rajikul_bg_color', array(
  'default'=>'#fff',
 ));
 $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize ,'rajikul_bg_color', array(
  'label'=>'Background Color',
  'section'=>'rejikul_colors',
  'setting'=>'rajikul_bg_color',
 )));

 $wp_customize->add_setting('rajikul_primary_color', array(
  'default'=>'rgb(227, 33, 217)',
 ));
 $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize ,'rajikul_primary_color', array(
  'label'=>'primary Color',
  'section'=>'rejikul_colors',
  'setting'=>'rajikul_primary_color',
 )));
 
}
add_action('customize_register','rajikul_customize_register');

// ক্লাস নাম্বার {23} এটার মাদ্ধমে কালার কাজ করে
function rajikul_theme_color_cus(){
  ?>
  <style>
    body{background: <?php echo get_theme_mod('rajikul_bg_color'); ?>}
    :root{--pink:<?php echo get_theme_mod('rajikul_primary_color'); ?>}
  </style>
  <?php
}
add_action('wp_head', 'rajikul_theme_color_cus');

