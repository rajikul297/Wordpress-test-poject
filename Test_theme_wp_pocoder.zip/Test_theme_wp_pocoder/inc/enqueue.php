<?php

// সিএসএস জাভাস্ক্রিপ্ট ফাইল কে কল করা হয়েছে
// ক্লাস নাম্বার {03}
function rajikul_css_js_file_colling(){
  wp_enqueue_style('rajikul_style',get_stylesheet_uri());

  wp_register_style('bxslider', get_template_directory_uri(). '/css/bxslider.min.css', array(), '4.2.12', 'all');
  //owl.carousel.min.css
  wp_register_style('owl.carousel', get_template_directory_uri(). '/css/owl.carousel.min.css', array(), '2.3.4', 'all');
  //owl.theme.default.min.css
  wp_register_style('owl.theme.default', get_template_directory_uri(). '/css/owl.theme.default.min.css', array(), '2.3.4', 'all');

  wp_register_style('bootstrap', get_template_directory_uri(). '/css/bootstrap.min.css', array(), '5.2.1', 'all');
  wp_register_style('custom', get_template_directory_uri(). '/css/custom.css', array(), '5.2.1', 'all');
  wp_enqueue_style('bootstrap');
  wp_enqueue_style('bxslider');
  wp_enqueue_style('owl.carousel');
  wp_enqueue_style('owl.theme.default');
  wp_enqueue_style('custom');

    // (Main.js)ফাইল এভাবে রেজিস্টার করতে হবে    
  wp_enqueue_script('jquery');
  wp_enqueue_script('bootstrap',get_template_directory_uri().'/js/bootstrap.min.css',array(), '5.2.1','true');
  wp_enqueue_script('bxslider',get_template_directory_uri().'/js/bxslider.min.js',array(), '4.2.12','true');
  wp_enqueue_script('owl.carousel.min',get_template_directory_uri().'/js/owl.carousel.min.js',array(), '2.3.4','true');
  wp_enqueue_script('main',get_template_directory_uri().'/js/main.js',array(), '5.2.1','true');
}
add_action('wp_enqueue_scripts','rajikul_css_js_file_colling');

function rajikul_add_google_fons(){
  wp_enqueue_style('rajikul_google_fons','https://fonts.googleapis.com/css2?family=Oswald&family=Roboto:wght@400;700&display=swap',false);
}
add_action('wp_enqueue_scripts','rajikul_add_google_fons');
