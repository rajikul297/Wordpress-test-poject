<?php
// ক্লাস নং (28) কাস্টম পোস্ট রেজিস্টার
function custom_slider(){
  register_post_type('slider', array(
    'labels'=> array(
      'name'=>('slider'),
      'singular_name'=>('slider'),
      'add new'=>('Add New slider'),
      'add_new_item'=>('Add New slider'),
      'edit_item'=>('Edit slider'),
      'new_item'=>('new item'),
      'viw_item'=>('viw item'),
      'not_found'=>('sorry, we could fin slider'),
    ),
    'menu_icon'=>'dashicons-format-gallery',
    'piblic'=> true,
    'piblicly_queryable'=> true,
    'menu_position'=> 5,
    'has_archive'=> true,
    'hierarchial'=> true,
    'show_ui'=> true,
    'capability_type'=> 'post',
    'rewrite'=> array('slag','slider'),
    'supports'=> array('title','thumbnail','editor','excerpt'),
    ));
    add_theme_support('post-thumbnails');
}
add_action('init','custom_slider');

// ক্লাস নং (24) কাস্টম পোস্ট রেজিস্টার
function custom_service(){
  register_post_type('service', array(
    'labels'=> array(
      'name'=>('service'),
      'singular_name'=>('service'),
      'add new'=>('Add New service'),
      'add_new_item'=>('Add New service'),
      'edit_item'=>('Edit service'),
      'new_item'=>('new item'),
      'viw_item'=>('viw item'),
      'not_found'=>('sorry, we could fin service'),
    ),
    'menu_icon'=>'dashicons-networking',
    'piblic'=> true,
    'piblicly_queryable'=> true,
    'menu_position'=> 5,
    'has_archive'=> true,
    'hierarchial'=> true,
    'show_ui'=> true,
    'capability_type'=> 'post',
    'taxonomies'=> array('category'),
    'rewrite'=> array('slag','service'),
    'supports'=> array('title','thumbnail','editor','excerpt'),
    ));
    add_theme_support('post-thumbnails');
}
add_action('init','custom_service');


//ক্লাস নং(৩৩) taxonomies/+ category এড করার ফাংশন / পোস্ট দেখানোর জন্য
function query_post_type($query){
  if(is_category()){
    $post_type = get_query_var('post_type');
    if($post_type){
      $post_type = $post_type;
    }else{
      $post_type = array('post','service');
      $query->set('post_type',$post_type);
      return $query;
    }
  }
}
add_filter('pre_get_posts','query_post_type');