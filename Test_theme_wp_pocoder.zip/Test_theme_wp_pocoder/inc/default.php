<?php
// <!-- title fuction -->
add_theme_support('title-tag');

//  ইমেজ থাম্বেল এরিয়া (এটা কোন কোন এরিয়ায় দেখাবে সেটা ফিক্সড করে [page][post])
add_theme_support('post-thumbnails', array('post','page'));
add_image_size('post-thumbnails', 970, 350, true);
add_image_size('service', 400, 200, true);
add_image_size('slider', 1900, 400, true);

add_theme_support('post-formats',['aside','gallery','image','video','audio']);
// ক্লাস নাম্বার {15} (read-more বাটন) বানানো হয়েছে
function rajikul_excerpt_more($more){
  return '<br> <br> <a class="readmore" href="' .get_permalink().'">'. 'Read More'. '</a>';
}
add_filter('excerpt_more','rajikul_excerpt_more');
// কতগুলো ওয়ার্ড শো করবে তা ফিক্সট করে
function rajikul_excerpt_length($length){
  return 10;
}
add_filter('excerpt_length','rajikul_excerpt_length',999);



/*========================
ক্লাস নম্বার (16)
পেজ নেব ফাংশন (এক পেজ থেকে আরেক পেজে যাওয়ার জন্য)
========================*/ 
function rajikul_pagenav(){
  global $wp_query, $wp_rewrite;
  $pages ='';
  $max = $wp_query->max_num_pages;
  if(! $current = get_query_var('paged'))$current = 1;
  $args['base']= str_replace(99999999,'%#%',get_pagenum_link(99999999));
  $args['total']= $max;
  $args['current']= $current;
  $total =1;
  $args['prev_text']= 'prev';
  $args['next_text']= 'next';  
  // কারেন্ট পেজ নাম্বার দেখাবে (1/25 2/24)
  if($max >1) echo '</pre><div class="wp_pagenave">'; 
  if($total == 1 && $max >1) $pages = '<p class="pages">page '.$current. '<span>of</span>' .$max. '</p>';
  echo $pages . paginate_links( $args );
  if($max > 1)echo'<pre> </div>';
}
function dashicon_not_issu(){
  wp_enqueue_style('dashicon');
}
add_action('wp_enqueue_scripts','dashicon_not_issu');