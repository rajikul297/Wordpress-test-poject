<?php
// সাইদবার রেজিস্টার ফাংশন 
function rajikul_widget_register(){
  register_sidebar(array(
    'name'=>__('Main Widget area','rajikul_language'),
    'id'=>'sidebar-1',
    'description' => __('Apperas in the sidebar in blog page and also other page', 'rajikul_language'),

    'before_widget'=> '<div class="child_sidebar">',
    'after_widget'=> '</div>',

    'before_title'=> '<div class="title">',
    'after_title'=> '</div>',
  ));
  
    // ফুটানার এরিয়া (1)(উইজেট)
    register_sidebar(array(
      'name'=>__('footer 1','rajikul_language'),
      'id'=> 'footer-1',
      'description'=>__('Apperas in the sidebar in blog page and also other page', 'rajikul_language'),

      'before_widget'=>'<div class="child_sidebar">',
      'after_widget'=>'</div>',

      'before_title'=>'<div class="title">',
      'after_title'=> '</div>',
    ));
    
    // ফুটানার এরিয়া (2)(উইজেট)
    register_sidebar(array(
      'name'=>__('footer 2','rajikul_language'),
      'id'=> 'footer-2',
      'description'=>__('Apperas in the sidebar in blog page and also other page', 'rajikul_language'),

      'before_widget'=>'<div class="child_sidebar">',
      'after_widget'=>'</div>',

      'before_title'=>'<div class="title">',
      'after_title'=> '</div>',
    ));
    
    // ফুটানার এরিয়া (3)(উইজেট)
    register_sidebar(array(
      'name'=>__('footer 3','rajikul_language'),
      'id'=> 'footer-3',
      'description'=>__('Apperas in the sidebar in blog page and also other page', 'rajikul_language'),

      'before_widget'=>'<div class="child_sidebar">',
      'after_widget'=>'</div>',

      'before_title'=>'<div class="title">',
      'after_title'=> '</div>',
    ));
    
    //ক্লাস নং(৩২) হোম পেজ এরিয়া (১)(উইজেট)
    register_sidebar(array(
      'name'=>__('homepage-1','rajikul_language'),
      'id'=> 'homepage-1',
      'description'=>__('Apperas in the sidebar in blog page and also other page', 'rajikul_language'),

      'before_widget'=>'<div class="child_homepage">',
      'after_widget'=>'</div>',

      'before_title'=>'<h2 class="title">',
      'after_title'=> '</h2>',
    ));
    
}
add_action('widgets_init','rajikul_widget_register');

