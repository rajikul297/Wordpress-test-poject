
  <!-- ক্লাস নাম্বার {08 
এটা দিয়ে কপিরাইট এরিয়ার টেক্সট চেঞ্জ করার অপশন -->
    <footer id="footer_area">
      <div id="footer">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <?php dynamic_sidebar( 'footer-1' );?>
            </div>
            <div class="col-md-4">
              <?php dynamic_sidebar( 'footer-2' );?>
            </div>
            <div class="col-md-4">
              <?php dynamic_sidebar( 'footer-3' );?>
            </div>
          </div>
        </div>
      </div>
    <section id="copyright_area">
    <div class="container">
      <div class="row"> 
        <p><?php echo get_theme_mod('rajikul_copyright_section');?></p>
      </div>
    </div>
    </div>
  </footer>

<?php wp_footer()?>
</body>
</html>