

        <!--==============ক্লাস নাম্বার {19}==================================-->
          <?php 
          // যখন পোস্ট থাকবে তখন (পোস্ট)দেখাবে 
          if(have_posts()):
            while (have_posts()) : the_post();
          ?>
          <div class="blog_area">
            <?php echo get_post_format( $post->ID );?>
            <span class="dashicons dashicons-format-<?php echo get_post_format( $post->ID );?>"></span>
            <!-- থাম্বেল এরিয়া -->
            <div class="post_thumb">
              <!-- ইমেজকে লিঙ্ক করে -->
              <a href=" <?php the_permalink();?>">  <?php the_post_thumbnail('post-thumbnails');?></a>
             
            </div>
            <div class="post_details">
              <!-- এটা দিয়ে পোস্টের টাইটেল শো করে -->
              <h2><a href=" <?php the_permalink();?>"> <?php the_title();?></a></h2>
              <!-- এটা না দিলে সকল পোষ্ট প্রথম পেজে শো করে  -->
               <?php the_content();?>
            </div>
          </div>

          <?php 
          // যখন পোস্ট না থাকবে তখন (পোস্ট)দেখাবে না 
          endwhile;
          else :
            _e('No Post Found');
          endif;
          ?>
      
