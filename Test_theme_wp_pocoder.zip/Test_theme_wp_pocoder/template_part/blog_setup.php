
        <!--==============ক্লাস নাম্বার {19}==================================-->
          <?php 
          // যখন পোস্ট থাকবে তখন (পোস্ট)দেখাবে 
          if(have_posts()):
            while (have_posts()) : the_post();
          ?>
          <div class="blog_area">
            <!-- থাম্বেল এরিয়া -->
            <div class="post_thumb">
               <!-- ইমেজকে লিঙ্ক করে -->
              <a href=" <?php the_permalink();?>">  <?php the_post_thumbnail('post-thumbnails');?></a>
          </div>
        <div class="post_details">
        <!-- এটা দিয়ে পোস্টের টাইটেল শো করে -->
        <h2><a href=" <?php the_permalink();?>"> <?php the_title();?></a></h2>
        <p><i class="fa-solid fa-calendar-days"></i> <?php echo the_time('D-j-F-Y');?> <span>At</span><i class="far fa-clock"></i><?php echo the_time(' g-i-a');?></p>
        <!-- এটা না দিলে সকল পোষ্ট প্রথম পেজে শো করে  -->
         <?php the_excerpt();?>
      </div>
    </div>

          <?php 
          // যখন পোস্ট না থাকবে তখন (পোস্ট)দেখাবে না 
          endwhile;
          else :
            _e('No Post Found');
          endif;
          ?>
          <!-- ক্লাস নম্বার {16} -->
          <div id="page_nav">
            <?php if('rajikul_pagenav') {rajikul_pagenav();} else{?>
              <?php next_post_link();?>
              <?php previous_post_link();?>
            <?php }?>
          </div>
                         
            
      