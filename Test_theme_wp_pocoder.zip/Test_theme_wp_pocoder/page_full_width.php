<?php
/*
*Template Name: Full Whith Page
*/ 
get_header();
?>

  
  <!-- ক্লাস নাম্বার {38} -->
  <section id="body_area">
    <div class="container">
      <div class="row">
       <div class="col-md-12">
          <?php 
          if(have_posts()):
            while (have_posts()) : the_post();
          ?> <div class="post_details">
        <!-- এটা দিয়ে পোস্টের টাইটেল শো করে -->
        <h2><a href=" <?php the_permalink();?>"> <?php the_title();?></a></h2>
        <p><i class="fa-solid fa-calendar-days"></i> <?php echo the_time('D-j-F-Y');?> <span>At</span><i class="far fa-clock"></i><?php echo the_time(' g-i-a');?></p>
      </div>
          <div class="blog_area">
            <div class="post_thumb">
              <a href=" <?php the_permalink();?>">  <?php the_post_thumbnail('post-thumbnails');?></a>
          </div>
        <div class="post_details">
         <?php the_content();?>
      </div>

          <?php endwhile;
          else :
            _e('No Post Found');
          endif;?>                        
          </div>      
       </div>
      </div>
    </div>
  </section>
  <section id="body_area">
    <div class="container">
      <div class="row">
    <div style="background:red; width:32%;margin: 5px;height:200px;" class="col-md-4"></div>
    <div style="background:red; width:32%;margin: 5px;height:200px;" class="col-md-4"></div>
    <div style="background:red; width:32%;margin: 5px;height:200px;" class="col-md-4"></div>
      </div>
    </div>
  </section>
<h3 style="color:red">Template page_full_white.php</h3>
<?php get_footer();?>